# YTÖD - AI Destekli Yazılı Anlatım Değerlendirme

## Kurulum

1. Depoyu klonlayın:
```bash
git clone https://github.com/yourusername/ytod.git
cd ytod
```

2. Bağımlılıkları yükleyin:
```bash
npm install
```

3. Ortam değişkenlerini ayarlayın:
```bash
cp .env.example .env
# .env dosyasını açıp OPENAI_API_KEY değerini girin
```

4. Geliştirme sunucusunu başlatın:
```bash
npm run dev
```

## Proje Yapısı

- `pages/index.js`: Ana sayfa (React bileşeni)
- `pages/api/evaluate.js`: OpenAI API entegrasyonu için backend

## Kullanım

- Tarayıcıdan `http://localhost:3000` adresine gidin.
- Dil seviyesi seçin (A1-C1) ve metni girin.
- "Değerlendir" butonuna basın, AI tarafından puanlama sonucu gösterilecektir.
