import { useState } from "react";

export default function Home() {
  const [level, setLevel] = useState("");
  const [text, setText] = useState("");
  const [result, setResult] = useState(null);

  const handleEvaluate = async () => {
    const prompt = `Seviye: ${level}. Metin: ${text}.`;
    const response = await fetch("/api/evaluate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt }),
    });
    const data = await response.json();
    setResult(data.result);
  };

  return (
    <div style={{ maxWidth: "600px", margin: "auto", padding: "20px" }}>
      <h1>YTÖD | Hadi Beni Değerlendir.</h1>
      <select value={level} onChange={(e) => setLevel(e.target.value)}>
        <option value="">Dil Seviyesini Seçin</option>
        {["A1", "A2", "B1", "B2", "C1"].map((lvl) => (
          <option key={lvl} value={lvl}>
            {lvl}
          </option>
        ))}
      </select>
      <textarea
        rows={8}
        style={{ width: "100%", marginTop: "10px" }}
        placeholder="Öğrencinin metnini girin..."
        value={text}
        onChange={(e) => setText(e.target.value)}
      />
      <button
        onClick={handleEvaluate}
        disabled={!level || !text}
        style={{ marginTop: "10px" }}
      >
        Değerlendir
      </button>
      {result && (
        <pre style={{ background: "#f4f4f4", padding: "10px", marginTop: "20px" }}>
          {result}
        </pre>
      )}
    </div>
  );
}
